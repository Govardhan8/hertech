package login.db.registration;

public interface MyProvider {
	//User name for DB
	String username="system";
	//Password for DB
	String password="India123";
	//URL for the Databse in your system
	String url="jdbc:oracle:thin:@localhost:1521:XE";
}
