package login.db.registration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDaoImpl implements CustomerDao{

	static Connection con;
	static PreparedStatement ps;
	@Override
	public int insertCustomer(Customer c) {
		
		int status=0;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			
				ps=con.prepareStatement("insert into login(userid,password,name) values(?,?,?)");
				ps.setString(1, c.getUsername());
				ps.setString(2, c.getPassword());
				ps.setString(3, c.getName());
				status=ps.executeUpdate();
				con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return status;
	}

	@Override
	public Customer getCustomer(String userid, String pass) {
		Customer c=new Customer();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
		
			ps=con.prepareStatement("select * from login where userid=? and password=?");
			ps.setString(1, userid);
			ps.setString(2, pass);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c.setUsername(rs.getString(1));
				c.setPassword(rs.getString(2));
				c.setName(rs.getString(3));
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return c;
	}

}
