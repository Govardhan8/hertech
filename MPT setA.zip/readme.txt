Create Project
>ng new mobile-app-rishi46007440

 

Start Project Server
>ng serve -o

 

Create Components
>ng g c add
>ng g c show

 

Create Service
>ng g s mobile

 

Install Bootstrap
>npm i bootstrap

Install json
>npm i -g json-server

Create json file in src
mobilelist.json

 

Run json server
>json-server mobilelist.json