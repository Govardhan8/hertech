import { Component, OnInit } from '@angular/core';
import { MobileService } from '../mobile.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  mobile;

  constructor(private ms:MobileService, private router:Router) { 
    ms.getAll().subscribe((res) => this.mobile =res)
   }

   deleteProduct(mid){
    this.ms.delete(mid).subscribe(()=>{ 
    
    history.go();
  })
  }

  ngOnInit() {
  }

}
