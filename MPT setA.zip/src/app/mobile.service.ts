import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MobileService {

  constructor(private http:HttpClient) { }

  // to get all the details from the json file
  getAll(){
    return this.http.get('http://localhost:3000/mobile')
  }

  // adding details in the json server
 add(mobile) {
    let opt = new HttpHeaders({'Content-Type':'application/json'})
    return this.http.post('http://localhost:3000/mobile', mobile,{headers:opt})
  }
  // delete button to delete the mobile details from show page and reflecting the changes in json file
 delete(mid){
    let opt = new HttpHeaders({'Content-Type':'application/json'})
    return this.http.delete('http://localhost:3000/mobile/' +mid)
  }
}
