package com.ui;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

import com.bean.CreateAccount;
import com.exception.InvalidMobileNumberException;
import com.service.BankServiceImpl;

public class Main {
	static Scanner in=new Scanner(System.in);
	static BankServiceImpl bs=new BankServiceImpl();
	public static void main(String[] args) {
		List<CreateAccount> l=new ArrayList<>();				
		ArrayBlockingQueue<String> q=new ArrayBlockingQueue<>(100);
		CreateAccount cr=null;
		System.out.println("WELCOME");
		
		while(true){
		System.out.println("Select the operation you want to do:");
		System.out.println("1.create account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		int option=0;
		boolean flag=false,f=false;
		option=in.nextInt();
		long amount=0;
		
		switch (option) {
			
		case 1:
				while(cr==null)
				{
					  cr=populateCr();					 			 				    
				}
				try{
				l.addAll(bs.addAccount(cr));		 
				  System.out.println("Successfully created your account:");
				  System.out.println("Your account number is:"+cr.getAccountno());
				}
				finally
				{
				cr=null;	
				}
			break;
		case 2:
				System.out.println("Enter the account number:");
				int num=in.nextInt();
				System.out.println("Available balance: "+bs.viewDetails(num,l));
				
			break;	
		case 3:
			int n=0;
			while(flag==false)
			{
				System.out.println("Enter the account number:");
				 n=in.nextInt();
				flag=deposit(n,l);
			}
			
			while(!f)
			{
			System.out.println("Enter the amount to be deposited:");
			amount=in.nextLong();
			f=amountValidation(amount);
			}
			System.out.println("Your available balance is:"+bs.deposit(n, amount, l));
			q.addAll(bs.transactions("/n"));
			break;
		case 4:
			flag=false;
			int n1=0;
			while(!flag)
			{
			System.out.println("Enter the account number:");
			n1=in.nextInt();
			flag=withdraw(n1, l);
			}
			while(!f)
			{
			System.out.println("Enter the amount to be withdrawn:");
			amount=in.nextLong();
			f=amountValidation(amount);
			}
			System.out.println("Your available balance is:"+bs.withdraw(n1, amount, l));
			q.addAll(bs.transactions("/n"));
			break;
		case 5:
			int ns=0,nr=0;
			flag= false;
			while(!flag)
			{
			System.out.println("Enter your account number:");
			 ns=in.nextInt();
			System.out.println("Enter reciepient account number:");
			 nr=in.nextInt();
			 flag=fundtransfer(ns, nr, l);
			}
			while(!f)
			{
			System.out.println("Enter the amount to be transferred:");
			amount=in.nextLong();
			f=amountValidation(amount);
			}
			System.out.println("Your available balance is:"+bs.fundTransfer(ns,nr, amount, l));
			q.addAll(bs.transactions("/n"));
			break;
		case 6:
			Set<String> s=new LinkedHashSet<>();
			s.addAll(q);
			System.out.println(s);
			break;
		case 7:
			System.out.println("Thank you! for using our service.");
			break;
		default:
			System.out.println("Enter valid option");
			break;
		}
	}
	}
	public static CreateAccount populateCr()
	{
		CreateAccount cr=new CreateAccount();
		int accountno;
		String custname,city,cellnumber;
		accountno = (int) (1000*Math.random());
		cr.setAccountno(accountno);
		System.out.println("Enter your name:");
		custname=in.next();
		cr.setCustname(custname);
		System.out.println("Enter your city:");
		city=in.next();
		cr.setCity(city);
		System.out.println("Enter your CellNumber:");
		cellnumber=in.next();				 
		cr.setCellnumber(cellnumber);		  
		if(bs.validateMobileNumber(cellnumber))
		{ 
				  return cr;
		}	
		try {
			throw new InvalidMobileNumberException();
		}
		catch (InvalidMobileNumberException e) {
			System.out.println(e+" Enter valid Mobile Number!");
		}
		return null;
	}
	public static boolean deposit(int n,List<CreateAccount> l)
	{
		if(bs.validateAccountNumber(n, l))
		{
			return true;
		}	
		System.out.println("Enter valid account number:");
		return false;
	}
	public static boolean withdraw(int n,List<CreateAccount> l)
	{
		if(bs.validateAccountNumber(n, l))
		{
			return true;
		}	
		System.out.println("Enter valid account number:");
		return false;
	}
	public static boolean fundtransfer(int n,int i,List<CreateAccount> l)
	{
		if(bs.validateAccountNumber(n, l)&&(bs.validateAccountNumber(i, l)))
		{
			return true;
		}
		System.out.println("Enter valid account number:");
		return false;
	}
	public static boolean amountValidation(long amount)
	{
		if(amount>0)
			{
			return true;
			}
		System.out.println("Enter valid amount:");
		return false;
			
	}
}
