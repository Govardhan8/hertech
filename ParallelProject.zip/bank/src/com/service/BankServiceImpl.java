package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.exception.InvalidAccountNumber;
import com.exception.InvalidMobileNumberException;
import com.bean.CreateAccount;
import com.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	BankDaoImpl a=new BankDaoImpl();
	
	@Override
	public List<CreateAccount> addAccount(CreateAccount cr) {
		BankDaoImpl bd=null;
		bd=new BankDaoImpl();
		return bd.addAccount(cr);

	}

	public boolean validateMobileNumber(String cell) {
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher idMatcher = phonePattern.matcher(cell);
		
		if(!idMatcher.matches())
			return false;
		else
			return true;
	}

	@Override
	public long viewDetails(int s, List<CreateAccount> l) {
		try{
			if(!validateAccountNumber( s,l))
			{
				throw new InvalidAccountNumber();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return a.viewDetails(s, l);
		
	}
	

	@Override
	public long deposit(int i,long s,List<CreateAccount> l) {
		
		try{
			if(!validateAccountNumber( i,l))
			{
				throw new InvalidAccountNumber();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return a.deposit(i,s,l);
		
	}
	
	public boolean validateAccountNumber(int i,List<CreateAccount> l) {
		Iterator<CreateAccount> itr=l.iterator();
		while(itr.hasNext())
		{
			CreateAccount acc=itr.next();
			if(acc.getAccountno()==i)
				return true;
		}
		return false;
	}

	@Override
	public long withdraw(int i,long s,List<CreateAccount> l) {
		try{
			if(!validateAccountNumber( i,l))
			{
				throw new InvalidAccountNumber();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return a.withdraw(i,s,l);
		
	}
	@Override
	public long fundTransfer(int s, int b, long amt, List<CreateAccount> l) {
		try{
			if(!validateAccountNumber( s,l))
			{
				throw new InvalidAccountNumber();
			}
			if(!validateAccountNumber(b,l))
			{
				throw new InvalidAccountNumber();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return a.fundTransfer(s, b, amt, l);
	}
	public ArrayList<String> transactions(String s)
	{
		ArrayList<String> transaction=new ArrayList<>();
		transaction.addAll(a.transactions(" "));
		return transaction;
	}
}
