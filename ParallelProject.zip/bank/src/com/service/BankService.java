package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.CreateAccount;

public interface BankService {
	public List<CreateAccount> addAccount(CreateAccount cr);
	public long deposit(int i,long s,java.util.List<CreateAccount> l);
	public long withdraw(int i,long s,java.util.List<CreateAccount> l);
	long viewDetails(int s, List<CreateAccount> l);
	long fundTransfer(int s, int b, long amt, List<CreateAccount> l);
}
