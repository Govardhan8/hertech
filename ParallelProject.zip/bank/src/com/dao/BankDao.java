package com.dao;

import java.awt.List;
import java.util.ArrayList;

import com.bean.CreateAccount;

public interface BankDao {
	public java.util.List<CreateAccount> addAccount(CreateAccount cr);
	public long deposit(int i,long s,java.util.List<CreateAccount> l);
	public long withdraw(int i,long s,java.util.List<CreateAccount> l);
	long fundTransfer(int s, int b, long amt,java.util.List<CreateAccount> l);
	long viewDetails(int s, java.util.List<CreateAccount> l);
}
