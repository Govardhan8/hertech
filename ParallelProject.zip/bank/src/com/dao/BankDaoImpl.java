package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.bean.CreateAccount;
import com.service.BankServiceImpl;

import com.util.BankCollections;

public class BankDaoImpl implements BankDao {

	BankCollections bc=new BankCollections();
	@Override
	public List<CreateAccount> addAccount(CreateAccount cr) {
		
		return bc.add(cr);

	}

	@Override
	public long viewDetails(int s, List<CreateAccount> l) {
		
		return bc.balance(s,l);
	}

	@Override
	public long deposit(int i,long s,List<CreateAccount> l) {
		
		return bc.deposit(i,s, l);
		
	}
	@Override
	public long withdraw(int i,long s,List<CreateAccount> l) {
		
		return bc.withdraw(i,s,l);
		
	}
	@Override
	public long fundTransfer(int s, int b, long amt, List<CreateAccount> l) {
		
		return bc.fundTransfer(s, b, amt, l);
	}

	public ArrayList<String> transactions(String s)
	{
		ArrayList<String> transaction=new ArrayList<>();
		transaction.addAll(bc.transactions(""));
		return transaction;
	}


}
