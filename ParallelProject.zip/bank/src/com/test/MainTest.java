package com.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bean.CreateAccount;
import com.service.BankServiceImpl;

public class MainTest {
	CreateAccount a,d,c,b;	 
	
	BankServiceImpl bs=new BankServiceImpl();
	long bal=0;

	 static List<CreateAccount> li=new ArrayList<>();
	@Before
	public void setUp() throws Exception {
		 
		
	}
	@After
	public void tearDown() throws Exception
	{
		
	}
	
	@Test
	public void testAddAccount()
	{
		a=new CreateAccount(2,"Gaurav","Chennai","8970399921",80000);	
		c=new CreateAccount(1,"Rishi","Bangalore","8970342321",100000);	
		b=new CreateAccount(10, "Ishaque", "Bangalore", "8920197827", 50000);
		d=new CreateAccount(11,"Abhi","Bangalore","8996342321",32000);	
		li.addAll(bs.addAccount(c));
		li.addAll(bs.addAccount(b));
		li.addAll(bs.addAccount(a));
		li.addAll(bs.addAccount(d));
		//System.out.println(li);
	}
	@Test
	public void testDetails()
	{
		assertEquals(32000, bs.viewDetails(11, li));
	}
	@Test
	public void testDeposit()
	{
		assertEquals(120000, bs.deposit(1, 20000, li));		
	}
	@Test
	public void testWithraw()
	{
		assertEquals(40000, bs.withdraw(10, 10000, li));
		
	}
	@Test
	public void testtransfer()
	{
		assertEquals(70000, bs.fundTransfer(2,11, 10000, li));
		System.out.println(li);
	}
	}

