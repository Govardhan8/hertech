package com.exception;

public class InvalidAccountNumber extends Exception{

	public InvalidAccountNumber() {
		super();
		
	}

	@Override
	public String toString() {
		return "InvalidAccountNumber";
	}
	
	
}
