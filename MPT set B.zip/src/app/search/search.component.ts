import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private ps:ProductService,private router:Router) { }
products;//variable to store the product details
s;b;//to store the search value
  ngOnInit() {
  }
  //search function
search()
{
  if(this.s==null)
  {
    this.router.navigate(['search'])
    this.products=null;
    
  }
  else
    this.b=this.s;
    this.ps.getAll().subscribe((res)=>this.products=res)
    this.router.navigate([''])
}
}
