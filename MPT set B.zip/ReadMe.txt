Creating a new project
>ng new e-commerce-Govarn46007431

Open the directory to the project
>cd e-commerce-Govarn46007431

Adding Components
>ng g c search
>ng g c product-list

Adding Service
>ng g s product

Create a json file named db.json

Install the following:
 1)For bootstrap
	>npm i bootstrap
 2)For json server
	>npm i -g json-server

Run the Angular server
>ng serve -o

For Run the json-server
 Open the directory to source
	>cd src
 Run the json-server
	>json-server db.json
