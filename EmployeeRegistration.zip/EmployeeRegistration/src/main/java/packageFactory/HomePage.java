package packageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	//Local driver instance
	WebDriver driver;

	public HomePage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//Web Elements for the page 
	
	//For the links on the page
	
	//For the contact us link
	
	@FindBy(linkText = "Contact Us")
	WebElement contact;

	//For the registration page link
	@FindBy(linkText = "Register")
	WebElement register;

	//For the header content of the page
	@FindBy(xpath = "/html/body/div/header")
	WebElement header;

	public WebElement contact() {
		return contact;
	}

	public WebElement register() {
		return register;
	}

	public WebElement header() {
		return header;
	}

}
