package packageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmployeeRegistrationPage {
	//Local driver instance
	WebDriver driver;

	public EmployeeRegistrationPage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//Web Elements for the page 
	//Employee name 
	@FindBy(name = "emp_name")
	WebElement name;
	//Employee number
	@FindBy(name = "num")
	WebElement number;
	//Employee address
	@FindBy(name = "S2")
	WebElement address;
	//Employee job location
	@FindBy(name = "location")
	WebElement location;
	//Employee contact number
	@FindBy(name = "txtFName1")
	WebElement contact;
	//Employee designation
	@FindBy(name = "mydropdown")
	WebElement designation;
	//Employee email id
	@FindBy(name = "email_id")
	WebElement email;
	//Submit button on the page
	@FindBy(name = "B4")
	WebElement submit;
	//Reset button on the page
	@FindBy(name = "B5")
	WebElement reset;

	public WebElement name() {
		return name;
	}

	public WebElement number() {
		return number;
	}

	public WebElement address() {
		return address;
	}

	public WebElement contact() {
		return contact;
	}

	public WebElement location() {
		return location;
	}

	public WebElement designation() {
		return designation;
	}

	public WebElement email() {
		return email;
	}

	public WebElement submit() {
		return submit;
	}

	public WebElement reset() {
		return reset;
	}
}
