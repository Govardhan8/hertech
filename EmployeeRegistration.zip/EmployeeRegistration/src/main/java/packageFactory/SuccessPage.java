package packageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SuccessPage {
	//Local instance of the driver
	WebDriver driver;

	public SuccessPage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//For the final message displayed in the page
	@FindBy(xpath = "/html/body/h1")
	WebElement message;

	public WebElement message() {
		return message;
	}
}
