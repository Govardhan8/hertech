package stepDefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import packageFactory.EmployeeRegistrationPage;
import packageFactory.HomePage;
import packageFactory.SuccessPage;

public class Steps {

	WebDriver driver;
	EmployeeRegistrationPage employee;
	HomePage home;
	SuccessPage success;

	@Before
	public void setup() {
		//Setting up the webdriver 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\GOVARN\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		//To maximize the window
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//Loading the driver into the PageFactories
		employee = new EmployeeRegistrationPage(driver);
		home = new HomePage(driver);
		success = new SuccessPage(driver);
	}

	@Given("^the home page is opened$")
	public void the_home_page_is_opened() throws Throwable {
		//Loading the home page
		driver.get("file:///C:/Users/GOVARN/Desktop/GOVA/HTML/EmployeeRegistration/webpages/Home.html");
	}

	@When("^the home page is launched, the header is verified$")
	public void the_home_page_is_launched_the_header_is_verified() throws Throwable {
		//The header value is stored in header string
		String header = home.header().getText();
		assertEquals("Home Register Contact Us", header);
		//For one second gap between the next operation
		Thread.sleep(1000);
	}

	@Then("^the contact us page is opened$")
	public void the_contact_us_page_is_opened() throws Throwable {
		//Going to the contact page
		home.contact().click();
	}

	@And("^the title of the page is verified$")
	public void the_title_of_the_page_is_verified() throws Throwable {
		//Getting the Title of the page
		assertEquals("Contact Us", driver.getTitle());
		Thread.sleep(1000);

	}

	@When("^registration page is opened$")
	public void registration_page_is_opened() throws Throwable {
		//Going back to the home page
		driver.navigate().back();
		Thread.sleep(1000);
		//Clicking on the registration page link
		home.register().click();
		Thread.sleep(1000);
	}

	@Then("^the title of the page is verified to register$")
	public void the_title_of_the_page_is_verified_to_register() throws Throwable {
		//Verifying the title of registration page
		assertEquals("Employee Registration Page", driver.getTitle());
		Thread.sleep(1000);
	}

	@When("^the submit is clicked without entering any value$")
	public void the_submit_is_clicked_without_entering_any_value() throws Throwable {
		//Submitting without entering any fields
		employee.submit().click();
	}

	@Then("^an alert to enter the 'Please fill in the 'Your Employee Name box'' is displayed$")
	public void an_alert_to_enter_the_Please_fill_in_the_Your_Employee_Name_box_is_displayed() throws Throwable {
		//Getting the alert
		Alert alert = driver.switchTo().alert();
		//Alert for employee name
		assertEquals("Please fill in the 'Your Employee Name' box.", alert.getText());
		Thread.sleep(1000);
		//Accepting the alert to proceed
		alert.accept();
	}

	@When("^the submit is clicked without entering employee number$")
	public void the_submit_is_clicked_without_entering_employee_number() throws Throwable {
		//Entering the name of the employee
		employee.name().sendKeys("Govardhan");
		Thread.sleep(1000);
		employee.submit().click();
	}

	@Then("^an alert saying 'Enter Employee Number' is displayed$")
	public void an_alert_saying_Enter_Employee_Number_is_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		//Alert for employee number
		assertEquals("Enter Employee Number", alert.getText());
		Thread.sleep(1000);
		alert.accept();
	}

	@When("^a character is entered in Employee number$")
	public void a_character_is_entered_in_Employee_number() throws Throwable {
		//Entering a character
		employee.number().sendKeys("a");
		Thread.sleep(1000);
	}

	@Then("^an alert saying 'Enter Number' is displayed$")
	public void an_alert_saying_Enter_Number_is_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		//Alert for invalid number input
		assertEquals("Enter Number", alert.getText());
		Thread.sleep(1000);
		alert.accept();
		//Entering a valid number
		employee.number().sendKeys("46001122");
	}

	@When("^a character is entered in contact$")
	public void a_character_is_entered_in_contact() throws Throwable {
		//Entering a character in contact 
		employee.contact().sendKeys("a");
		Thread.sleep(1000);
	}

	@Then("^an alert saying 'Enter Number' will be displayed$")
	public void an_alert_saying_Enter_Number_will_be_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		//Alert for invalid input
		assertEquals("Enter Number", alert.getText());
		Thread.sleep(1000);
		alert.accept();
		//Entering a valid contact
		employee.contact().sendKeys("9945872024");
	}

	@When("^the submit button is clicked without selecting job location$")
	public void the_submit_button_is_clicked_without_selecting_job_location() throws Throwable {
		//Entering the address
		employee.address().sendKeys("Thyagaraja Nagar");
		Thread.sleep(1000);
		employee.submit().click();
	}

	@Then("^an alert saying 'Select Your Job Location' is displayed$")
	public void an_alert_saying_Select_Your_Job_Location_is_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		//Alert for not selecting the job locationg
		assertEquals("Select your Job Location", alert.getText());
		Thread.sleep(1000);
		alert.accept();
		//Selecting a job location
		Select location = new Select(employee.location());
		location.selectByVisibleText("Bangalore");
		Thread.sleep(1000);
	}

	@When("^an invalid email pattern is entered$")
	public void an_invalid_email_pattern_is_entered() throws Throwable {
		//Selecting a designation
		Select designation = new Select(employee.designation());
		designation.selectByVisibleText("Project Manager");
		Thread.sleep(1000);
		//Entering an invalid email id
		employee.email().sendKeys("Gova");
		Thread.sleep(1000);
		employee.submit().click();

	}

	@Then("^an alert saying 'You have entered an invalid email address!' is displayed$")
	public void an_alert_saying_You_have_entered_an_invalid_email_address_is_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		//Alert for invalid email id
		assertEquals("You have entered an invalid email address!", alert.getText());
		Thread.sleep(1000);
		alert.accept();

	}

	@Then("^after entering all the values and submit button is clicked$")
	public void after_entering_all_the_values_and_submit_button_is_clicked() throws Throwable {
		//Clearing the already entered value
		employee.email().clear();
		//Entering a valid email id
		employee.email().sendKeys("govardhan@gmail.com");
		Thread.sleep(1000);		
	}

	@When("^the success page is loaded$")
	public void the_success_page_is_loaded() throws Throwable {
		//The success page is loaded
		employee.submit().click();
	}

	@Then("^the message on the screen should be 'Registered Successfully!\\.\\.'$")
	public void the_message_on_the_screen_should_be_Registered_Successfully() throws Throwable {
		//Checking the message on the screen
		assertEquals("Registered Successfully!", success.message().getText());
	}

	@And("^the title of the page should be verified, to confirm the employee is registered$")
	public void the_title_of_the_page_should_be_verified_to_confirm_the_employee_is_registered() throws Throwable {
		//Verifying the title of the success page
		assertEquals("Confimation Page", driver.getTitle());
		//Closing the window after successful completion of the operation
		driver.quit();
	}
}
